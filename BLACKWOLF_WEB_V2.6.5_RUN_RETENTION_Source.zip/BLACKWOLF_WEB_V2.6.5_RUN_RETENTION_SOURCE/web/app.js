const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];

const state = {
  files: { master:null, issue:null, daily:null, m190:null, sm:null, blacklist:null },
  etl: { valid:0, invalid:0, duplicates:0, errors:[] },
  engineReady:false,
  currentRunId: localStorage.getItem('blackwolf.currentRunId') || '',
  run:null,
  summary:null,
  page:1,
  pageSize:50,
  total:0,
  polling:null,
  settings:{language:'th',theme:'light',storageDir:''}
};

const pageTitles = {
  th:{prepare:'เตรียมไฟล์และรัน',approval:'ตรวจผลและดาวน์โหลด',dashboard:'แดชบอร์ดผู้บริหาร',report:'รายงานผู้บริหาร',history:'ประวัติการรัน',settings:'การตั้งค่า'},
  en:{prepare:'Prepare & Run',approval:'Approval & Download',dashboard:'Executive Dashboard',report:'Executive Report',history:'Run History',settings:'Settings'}
};

const translations = {
  th:{
    settingsTitle:'Settings & System Information',settingsSubtitle:'ตั้งค่าภาษา ธีม การจัดเก็บไฟล์ การช่วยเหลือ และตรวจสอบสถานะระบบ',refreshStatus:'รีเฟรชสถานะ',
    languageTitle:'ภาษา',languageDesc:'เลือกภาษาหลักของเมนูและหน้าการตั้งค่า',themeTitle:'ธีมขาว–ดำ',themeDesc:'สลับระหว่างโหมดสว่างและโหมดมืด',lightTheme:'ขาว',darkTheme:'ดำ',
    supportTitle:'แจ้งปัญหา',supportDesc:'เปิดกลุ่ม LINE สำหรับแจ้งปัญหาและติดตามการแก้ไข',manualTitle:'ดาวน์โหลดคู่มือ PDF',manualWaiting:'รอเพิ่มไฟล์คู่มือ BLACKWOLF_User_Manual.pdf',manualButtonWaiting:'ยังไม่มีไฟล์คู่มือ',
    storageTitle:'เลือกจัดเก็บไฟล์',storageDesc:'ผลลัพธ์แต่ละ Run จะถูกคัดลอกไปยังโฟลเดอร์ที่เลือก โดยไม่ลบไฟล์ในระบบ',currentStorage:'โฟลเดอร์ปัจจุบัน',chooseFolder:'เลือกโฟลเดอร์',openFolder:'เปิดโฟลเดอร์',useDefault:'ใช้ค่าเริ่มต้น',storageNote:'ระบบจะสร้างโฟลเดอร์ BLACKWOLF_รหัสรัน ภายในตำแหน่งที่เลือกโดยอัตโนมัติ',
    statusTitle:'สถานะระบบ',statusDesc:'ตรวจสอบ Local Engine, Excel, พื้นที่จัดเก็บ, คู่มือ และงานที่กำลังรัน',engineLabel:'Local Engine',storageLabel:'พื้นที่จัดเก็บ',manualLabel:'คู่มือ PDF',activeRunLabel:'Run ที่กำลังทำงาน',
    systemInfoTitle:'ข้อมูลระบบ',systemInfoDesc:'รายละเอียดเวอร์ชันและการประมวลผล',importantTitle:'ข้อควรทราบ',importantDesc:'ปิดไฟล์ Excel ต้นฉบับก่อนเริ่มประมวลผล',importantText1:'ห้ามปิด Microsoft Excel ระหว่างประมวลผล และควรปิดไฟล์ Master กับเช็คสถานะ ISSUE ที่เปิดค้างอยู่ก่อนกด Run',importantText2:'ระบบไม่เขียนทับไฟล์ต้นฉบับ แต่สร้างไฟล์ฉบับอัปเดตและ Backup แยกออกมา',
    resetTitle:'รีเซ็ตโปรแกรม',resetDesc:'คืนค่าภาษาและธีม ล้างประวัติ Run และไฟล์ชั่วคราวของ BLACKWOLF เท่านั้น',resetWarning:'ไม่ลบไฟล์ Excel ต้นฉบับที่อยู่ภายนอกโปรแกรม แต่ Run ที่กำลังทำงานจะถูกหยุด',resetButton:'รีเซ็ตโปรแกรม'
  },
  en:{
    settingsTitle:'Settings & System Information',settingsSubtitle:'Configure language, theme, result storage, support, and system status.',refreshStatus:'Refresh status',
    languageTitle:'Language',languageDesc:'Choose the main language for navigation and settings.',themeTitle:'Light / Dark Theme',themeDesc:'Switch between light and dark display modes.',lightTheme:'Light',darkTheme:'Dark',
    supportTitle:'Report a problem',supportDesc:'Open the LINE support group for issue reporting and follow-up.',manualTitle:'Download PDF Manual',manualWaiting:'Waiting for BLACKWOLF_User_Manual.pdf to be added.',manualButtonWaiting:'Manual not available',
    storageTitle:'Result storage',storageDesc:'Each Run result will be copied to the selected folder without deleting internal files.',currentStorage:'Current folder',chooseFolder:'Choose folder',openFolder:'Open folder',useDefault:'Use default',storageNote:'The system creates a BLACKWOLF_RunID subfolder automatically.',
    statusTitle:'System status',statusDesc:'Check the Local Engine, Excel, storage, manual, and active Runs.',engineLabel:'Local Engine',storageLabel:'Storage',manualLabel:'PDF Manual',activeRunLabel:'Active Runs',
    systemInfoTitle:'System information',systemInfoDesc:'Version and processing details.',importantTitle:'Important',importantDesc:'Close source Excel files before processing.',importantText1:'Do not close Microsoft Excel during processing. Close the Master and ISSUE workbooks before starting a Run.',importantText2:'The system does not overwrite selected source files. Updated copies and backups are created separately.',
    resetTitle:'Reset program',resetDesc:'Restore language and theme defaults, then clear BLACKWOLF Run history and temporary files.',resetWarning:'Original Excel files outside BLACKWOLF are not deleted. Active Runs will be stopped.',resetButton:'Reset program'
  }
};

function currentLang(){return state.settings.language==='en'?'en':'th'}
function tr(key){return translations[currentLang()]?.[key]||translations.th[key]||key}
function applyLanguage(language){
  state.settings.language=language==='en'?'en':'th';
  document.documentElement.lang=state.settings.language;
  document.body.dataset.language=state.settings.language;
  document.querySelectorAll('[data-i18n]').forEach(el=>{const key=el.dataset.i18n;if(translations[state.settings.language]?.[key])el.textContent=translations[state.settings.language][key]});
  const navLabels={th:{prepare:'เตรียมไฟล์และรัน',approval:'ตรวจผลและดาวน์โหลด',dashboard:'แดชบอร์ดผู้บริหาร',report:'รายงานผู้บริหาร',history:'ประวัติการรัน',settings:'การตั้งค่า'},en:{prepare:'Prepare & Run',approval:'Approval & Download',dashboard:'Executive Dashboard',report:'Executive Report',history:'Run History',settings:'Settings'}};
  $$('.nav-item').forEach(btn=>{const label=$('b',btn);if(label)label.textContent=navLabels[state.settings.language][btn.dataset.page]||label.textContent});
  const active=$('.nav-item.active')?.dataset.page||'prepare';
  $('#topTitle').textContent=pageTitles[state.settings.language][active]||active;
  $$('[data-language]').forEach(btn=>btn.classList.toggle('active',btn.dataset.language===state.settings.language));
}
function applyTheme(theme){
  state.settings.theme=theme==='dark'?'dark':'light';
  document.body.dataset.theme=state.settings.theme;
  $$('[data-theme-value]').forEach(btn=>btn.classList.toggle('active',btn.dataset.themeValue===state.settings.theme));
}


function isRunActive(){return state.run?.status==='running'||state.run?.status==='queued';}

function showToast(message, ms=2800){
  const el=$('#toast'); el.textContent=message; el.classList.add('show');
  clearTimeout(showToast.t); showToast.t=setTimeout(()=>el.classList.remove('show'),ms);
}
function fmt(n){return new Intl.NumberFormat('th-TH').format(Number(n)||0)}
function money(n){return `${new Intl.NumberFormat('th-TH',{maximumFractionDigits:2}).format(Number(n)||0)} บาท`}
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function setStatus(text, cls=''){
  const el=$('#globalStatus'); el.textContent=text; el.className='status-chip'+(cls?' '+cls:'');
}
function setPage(name){
  $$('.page').forEach(x=>x.classList.toggle('active',x.id===`page-${name}`));
  $$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.page===name));
  $('#topTitle').textContent=pageTitles[currentLang()][name]||name;
  if(name==='dashboard') loadDashboard();
  if(name==='approval') renderApproval();
  if(name==='report') renderReport();
  if(name==='history') loadHistory();
  if(name==='settings') loadSystemStatus();
}

async function checkHealth(){
  try{
    const res=await fetch('/api/health'); const data=await res.json();
    state.engineReady=!!data.ready;
    $('#engineDot').classList.toggle('ok',state.engineReady);
    if(state.engineReady){
      $('#engineState').textContent=`Local Engine Ready · V${data.version}`;
    }else{
      const checks=data.checks||{}; const missing=[];
      if(!checks.windows)missing.push('Windows');
      if(!checks.powershell)missing.push('Windows PowerShell');
      if(!checks.excel)missing.push('Microsoft Excel Desktop');
      $('#engineState').textContent=missing.length?`ขาด: ${missing.join(', ')}`:'Engine unavailable';
    }
  }catch(e){
    state.engineReady=false; $('#engineState').textContent='Engine unavailable';
  }
  refreshReady();
}

function bindNavigation(){
  $$('.nav-item').forEach(btn=>btn.addEventListener('click',()=>setPage(btn.dataset.page)));
  $$('.nav-go-prepare').forEach(btn=>btn.addEventListener('click',()=>setPage('prepare')));
  $('#menuToggle').addEventListener('click',()=>document.body.classList.toggle('sidebar-collapsed'));
  $('#cancelRunBtn').addEventListener('click',cancelCurrentRun);
  $('#deleteRunBtn').addEventListener('click',deleteCurrentRun);
  $('#shutdownBtn').addEventListener('click',async()=>{
    if(!confirm('ต้องการปิด BLACKWOLF Web หรือไม่?')) return;
    try{await fetch('/api/shutdown',{method:'POST'});}catch{}
    document.body.innerHTML='<div style="font-family:Tahoma;padding:50px;text-align:center"><h2>ปิดระบบแล้ว</h2><p>สามารถปิดแท็บนี้ได้</p></div>';
  });
}

function assignFile(field,file){
  state.files[field]=file||null;
  const input=$(`#${field}Input`); const slot=input?.closest('.file-slot');
  if(slot)slot.classList.toggle('selected',!!file);
  const label=$(`#${field}Name`);
  if(label)label.textContent=file?`${file.name} · ${formatBytes(file.size)}`:(slot?.classList.contains('optional')?'ยังไม่เลือก':'เลือกไฟล์');
  const removeBtn=$(`[data-remove-file="${field}"]`);
  if(removeBtn)removeBtn.classList.toggle('hidden',!file);
}
function removeSelectedFile(field){
  if(isRunActive()){showToast('กรุณาหยุดการรันก่อนเอาไฟล์ออก',4500);return;}
  assignFile(field,null);
  const input=$(`#${field}Input`);if(input)input.value='';
  refreshReady();showToast(`เอา ${fieldDisplay[field]||field} ออกจากรายการแล้ว`);
}
function detectField(filename){
  const n=String(filename||'').normalize('NFC').toLowerCase().replace(/\s+/g,' ').trim();
  const ext=(n.match(/\.[^.]+$/)||[''])[0];
  if(ext==='.txt'&&(n.includes('etl')||n.includes('entry')))return'etl';
  if(n.includes('เช็คกรมธรรม์ต่างด้าวที่ยังไม่ออก')||n.includes('foreign worker')&&n.includes('master'))return'master';
  if(n.includes('เช็คสถานะ issue')||(n.includes('issue')&&n.includes('status')))return'issue';
  if(n.includes('รายงานงานประกันแรงงานต่างด้าว')||n.includes('foreign worker report'))return'daily';
  if(n.includes('m190027_prd008_premium_by_policy')||(n.includes('m190')&&n.includes('premium')))return'm190';
  if(n.includes('ข้อมูลไม่สมบูรณ์')||n.includes('incomplete'))return'sm';
  if(n.includes('blacklist')||n.includes('black list'))return'blacklist';
  return'';
}
const fieldDisplay={master:'Master ล่าสุด',issue:'เช็คสถานะ ISSUE',daily:'Daily Report',m190:'M190 Premium by Policy',sm:'ข้อมูลไม่สมบูรณ์ / SM',blacklist:'Blacklist',etl:'ETL'};

async function processBulkFiles(fileList,source='ไฟล์'){
  const files=[...fileList].filter(f=>f&&f.name);
  if(!files.length){showToast('ไม่พบไฟล์ที่นำเข้ามา');return;}
  const grouped={master:[],issue:[],daily:[],m190:[],sm:[],blacklist:[],etl:[]};
  const unmatched=[];
  for(const file of files){
    const field=detectField(file.name);
    if(field)grouped[field].push(file);else unmatched.push(file);
  }
  const assigned=[];const replaced=[];const duplicates=[];
  for(const field of Object.keys(grouped)){
    const choices=grouped[field];if(!choices.length)continue;
    choices.sort((a,b)=>(b.lastModified-a.lastModified)||(b.size-a.size)||a.name.localeCompare(b.name,'th'));
    const chosen=choices[0];
    if(choices.length>1)duplicates.push(`${fieldDisplay[field]}: เลือก ${chosen.name} จาก ${choices.length} ไฟล์`);
    if(field==='etl'){
      $('#etlInput').value=await chosen.text();validateEtl();assigned.push([field,chosen.name]);continue;
    }
    if(state.files[field]&&state.files[field].name!==chosen.name)replaced.push(fieldDisplay[field]);
    assignFile(field,chosen);assigned.push([field,chosen.name]);
  }
  refreshReady();renderBulkDetection({assigned,unmatched,duplicates,replaced,source,total:files.length});
  const requiredCount=['master','issue','daily','m190'].filter(k=>state.files[k]).length;
  showToast(`แยกไฟล์อัตโนมัติแล้ว ${assigned.length} ประเภท · Required ${requiredCount}/4`,4500);
}

function renderBulkDetection({assigned=[],unmatched=[],duplicates=[],replaced=[],source='',total=0}){
  const box=$('#bulkDetection');
  const rows=[];
  if(assigned.length)rows.push(`<div class="detect-group ok"><strong>✓ จำแนกสำเร็จ ${assigned.length} ประเภท</strong>${assigned.map(([f,n])=>`<span><b>${esc(fieldDisplay[f])}</b>${esc(n)}</span>`).join('')}</div>`);
  if(duplicates.length)rows.push(`<div class="detect-group warn"><strong>⚠ พบหลายไฟล์ประเภทเดียวกัน</strong>${duplicates.map(x=>`<span>${esc(x)}</span>`).join('')}<small>ระบบเลือกไฟล์ที่แก้ไขล่าสุดให้อัตโนมัติ</small></div>`);
  if(unmatched.length)rows.push(`<div class="detect-group bad"><strong>! ไม่รู้จัก ${unmatched.length} ไฟล์</strong>${unmatched.slice(0,8).map(f=>`<span>${esc(f.name)}</span>`).join('')}${unmatched.length>8?`<small>และอีก ${unmatched.length-8} ไฟล์</small>`:''}</div>`);
  if(replaced.length)rows.push(`<div class="detect-note">แทนที่ไฟล์เดิม: ${esc(replaced.join(', '))}</div>`);
  if(!rows.length){box.classList.add('hidden');box.innerHTML='';return;}
  box.innerHTML=`<div class="detect-head"><span>${esc(source)} · รับมา ${fmt(total)} ไฟล์</span><button type="button" id="closeDetectionBtn">ซ่อนผล</button></div>${rows.join('')}`;
  box.classList.remove('hidden');$('#closeDetectionBtn')?.addEventListener('click',()=>box.classList.add('hidden'));
}

function clearOptionalFiles(){
  if(isRunActive()){showToast('กรุณาหยุดการรันก่อนล้างไฟล์',4500);return;}
  ['sm','blacklist'].forEach(field=>{assignFile(field,null);const input=$(`#${field}Input`);if(input)input.value='';});
  $('#etlFileInput').value='';$('#etlInput').value='';validateEtl();refreshReady();showToast('ล้างไฟล์ Optional และ ETL แล้ว');
}
function clearAllFiles(){
  if(isRunActive()){showToast('กรุณาหยุดการรันก่อนล้างไฟล์',4500);return;}
  Object.keys(state.files).forEach(field=>{assignFile(field,null);const input=$(`#${field}Input`);if(input)input.value='';});
  $('#bulkFileInput').value='';$('#folderInput').value='';$('#etlFileInput').value='';$('#etlInput').value='';validateEtl();
  $('#bulkDetection').classList.add('hidden');$('#bulkDetection').innerHTML='';refreshReady();showToast('ล้างไฟล์ทั้งหมดแล้ว');
}

function bindFiles(){
  Object.keys(state.files).forEach(field=>{
    const input=$(`#${field}Input`); if(!input)return;
    input.addEventListener('change',()=>{
      if(isRunActive()){input.value='';showToast('กรุณาหยุดการรันก่อนเปลี่ยนไฟล์',4500);return;}
      assignFile(field,input.files[0]||null);refreshReady();
    });
  });
  $$('.file-remove').forEach(btn=>btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();removeSelectedFile(btn.dataset.removeFile);}));
  $('#bulkFileInput').addEventListener('change',async e=>{if(isRunActive()){e.target.value='';showToast('กรุณาหยุดการรันก่อนเปลี่ยนไฟล์',4500);return;}await processBulkFiles(e.target.files,'เลือกไฟล์ทั้งหมด');e.target.value='';});
  $('#folderInput').addEventListener('change',async e=>{if(isRunActive()){e.target.value='';showToast('กรุณาหยุดการรันก่อนเปลี่ยนไฟล์',4500);return;}await processBulkFiles(e.target.files,'เลือกทั้งโฟลเดอร์');e.target.value='';});
  $('#clearOptionalBtn').addEventListener('click',clearOptionalFiles);
  $('#clearFilesBtn').addEventListener('click',clearAllFiles);
  const zone=$('#bulkDropZone');
  zone.addEventListener('click',()=>{if(isRunActive()){showToast('กรุณาหยุดการรันก่อนเปลี่ยนไฟล์',4500);return;}$('#bulkFileInput').click();});
  zone.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('#bulkFileInput').click();}});
  ['dragenter','dragover'].forEach(type=>zone.addEventListener(type,e=>{e.preventDefault();e.stopPropagation();zone.classList.add('dragging');if(e.dataTransfer)e.dataTransfer.dropEffect='copy';}));
  ['dragleave','dragend'].forEach(type=>zone.addEventListener(type,e=>{e.preventDefault();e.stopPropagation();zone.classList.remove('dragging');}));
  zone.addEventListener('drop',async e=>{e.preventDefault();e.stopPropagation();zone.classList.remove('dragging');if(isRunActive()){showToast('กรุณาหยุดการรันก่อนเปลี่ยนไฟล์',4500);return;}await processBulkFiles(e.dataTransfer.files,'ลากและวาง');});
  window.addEventListener('dragover',e=>e.preventDefault());
  window.addEventListener('drop',e=>{if(!zone.contains(e.target))e.preventDefault();});
}
function formatBytes(bytes){
  if(bytes<1024)return `${bytes} B`; if(bytes<1024**2)return `${(bytes/1024).toFixed(1)} KB`; return `${(bytes/1024**2).toFixed(1)} MB`;
}

function parseEtl(text){
  const valid=[], invalid=[], counts=new Map();
  String(text||'').replace(/^\uFEFF/,'').split(/\r?\n/).forEach((raw,i)=>{
    const line=raw.trim(); if(!line)return;
    const m=line.match(/^\s*(\d+)\.(\d+):([^:]+):(.+?)\s*$/);
    if(!m){invalid.push({line:i+1,text:raw,reason:'ต้องเป็น No.PropID:Policy:Group'});return;}
    const rec={no:Number(m[1]),propId:m[2],policy:m[3].trim(),group:m[4].trim()};
    if(!rec.policy||!rec.group){invalid.push({line:i+1,text:raw,reason:'Policy และ Group ห้ามว่าง'});return;}
    valid.push(rec); counts.set(rec.propId,(counts.get(rec.propId)||0)+1);
  });
  const dups=[...counts.entries()].filter(([,c])=>c>1);
  return {valid,invalid,duplicates:dups.reduce((s,[,c])=>s+c-1,0),dupIds:dups.map(([id])=>id)};
}
function validateEtl(){
  const r=parseEtl($('#etlInput').value); state.etl={valid:r.valid.length,invalid:r.invalid.length,duplicates:r.duplicates,errors:r.invalid};
  $('#etlValid').textContent=fmt(r.valid.length); $('#etlInvalid').textContent=fmt(r.invalid.length); $('#etlDup').textContent=fmt(r.duplicates); $('#etlChip').textContent=`${fmt(r.valid.length)} ROWS`;
  const ok=r.invalid.length===0&&r.duplicates===0;
  $('#etlMessage').textContent=r.valid.length===0?'ETL ว่างได้':ok?'รูปแบบ ETL ถูกต้อง':'กรุณาแก้ ETL ก่อนรัน';
  const box=$('#etlErrors');
  if(!ok){box.classList.remove('hidden');box.innerHTML=[...r.invalid.slice(0,10).map(x=>`<div>บรรทัด ${x.line}: ${esc(x.reason)} — ${esc(x.text)}</div>`),r.dupIds.length?`<div>PropID ซ้ำ: ${esc(r.dupIds.join(', '))}</div>`:''].join('');}
  else{box.classList.add('hidden');box.innerHTML='';}
  refreshReady(); return ok;
}
function bindEtl(){
  $('#etlInput').addEventListener('input',validateEtl);
  $('#etlFileInput').addEventListener('change',async e=>{const f=e.target.files[0];if(!f)return;$('#etlInput').value=await f.text();validateEtl();});
  $('#pasteEtlBtn').addEventListener('click',async()=>{try{$('#etlInput').value=await navigator.clipboard.readText();validateEtl();}catch{showToast('เบราว์เซอร์ไม่อนุญาต Clipboard กรุณากด Ctrl+V ในช่อง ETL');}});
  $('#clearEtlBtn').addEventListener('click',()=>{$('#etlInput').value='';validateEtl();});
}

function setCheck(key,status,detail){
  const row=$(`[data-check="${key}"]`); if(!row)return;
  row.classList.remove('ok','bad'); if(status)row.classList.add(status);
  $('small',row).textContent=detail;
}
function refreshReady(){
  const required=['master','issue','daily','m190']; const missing=required.filter(k=>!state.files[k]);
  setCheck('files',missing.length?'':'ok',missing.length?`ยังขาด: ${missing.map(k=>fieldDisplay[k]||k).join(', ')}`:'ไฟล์ Required ครบ 4 รายการ');
  const etlOk=state.etl.invalid===0&&state.etl.duplicates===0;
  setCheck('etl',etlOk?'ok':'bad',state.etl.valid===0?'ETL ว่าง — ระบบใช้ M190 เท่านั้น':etlOk?`ETL ผ่าน ${fmt(state.etl.valid)} รายการ`:'ETL มีบรรทัดผิดหรือ PropID ซ้ำ');
  setCheck('engine',state.engineReady?'ok':'bad',state.engineReady?'Local Engine พร้อมใช้งาน':'ไม่พบ Local Engine');
  const ready=missing.length===0&&etlOk&&state.engineReady;
  setCheck('ready',ready?'ok':'',ready?'พร้อม Validate และ Run Workflow':'ยังไม่พร้อมรัน');
  $('#runBtn').disabled=!ready;
  if(ready)setStatus('READY','ready'); else if(!state.run||state.run.status!=='running')setStatus('WAITING');
}

async function startRun(){
  if(!validateEtl())return;
  const form=new FormData();
  Object.entries(state.files).forEach(([k,f])=>{if(f)form.append(k,f,f.name)});
  form.append('etlText',$('#etlInput').value.trim());
  $('#runBtn').disabled=true; $('#cancelRunBtn').disabled=false; $('#deleteRunBtn').disabled=true; $('#progressPanel').classList.remove('hidden'); $('#logBox').textContent='';
  setStatus('RUNNING','running'); setProgress(3,'กำลังส่งไฟล์เข้า Local Engine'); setStep(4);
  try{
    const res=await fetch('/api/run',{method:'POST',body:form}); const data=await res.json();
    if(!res.ok||!data.ok)throw new Error(data.error||'เริ่ม Workflow ไม่สำเร็จ');
    state.currentRunId=data.runId; localStorage.setItem('blackwolf.currentRunId',data.runId); $('#currentRunLabel').textContent=data.runId;
    pollRun(data.runId);
  }catch(e){setStatus('FAILED','failed');setProgress(100,'เริ่ม Workflow ไม่สำเร็จ');showToast(e.message,5000);$('#runBtn').disabled=false;}
}
function setProgress(p,msg){$('#progressPercent').textContent=`${p}%`;$('#progressBar').style.width=`${p}%`;$('#progressMessage').textContent=msg;}
async function cancelCurrentRun(){
  if(!state.currentRunId)return;
  if(!confirm('ต้องการหยุดการรันนี้หรือไม่? ระบบจะปิด Excel Engine ของ Run นี้'))return;
  const btn=$('#cancelRunBtn');btn.disabled=true;
  try{
    const res=await fetch(`/api/cancel?id=${encodeURIComponent(state.currentRunId)}`,{method:'POST'});
    const data=await res.json();
    if(!res.ok||!data.ok)throw new Error(data.error||'หยุดการรันไม่สำเร็จ');
    setProgress(state.run?.progress||18,'กำลังหยุด Excel Engine');
    showToast('ส่งคำสั่งหยุดแล้ว');
  }catch(e){showToast(e.message||'หยุดการรันไม่สำเร็จ',5000);btn.disabled=false;}
}
async function deleteCurrentRun(){
  if(!state.currentRunId)return;
  if(isRunActive()){showToast('Run กำลังทำงาน กรุณากดหยุดก่อน',4500);return;}
  if(!confirm('ต้องการล้างข้อมูล Run นี้หรือไม่? ไฟล์ผลลัพธ์และประวัติของ Run นี้จะถูกลบ แต่ไฟล์ต้นฉบับในเครื่องจะไม่ถูกลบ'))return;
  const btn=$('#deleteRunBtn');btn.disabled=true;
  try{
    const res=await fetch(`/api/delete-run?id=${encodeURIComponent(state.currentRunId)}`,{method:'POST'});const data=await res.json();
    if(!res.ok||!data.ok)throw new Error(data.error||'ล้าง Run ไม่สำเร็จ');
    clearInterval(state.polling);state.currentRunId='';state.run=null;state.summary=null;localStorage.removeItem('blackwolf.currentRunId');$('#currentRunLabel').textContent='-';
    $('#progressPanel').classList.add('hidden');$('#logBox').textContent='';setProgress(0,'กำลังเตรียม...');setStatus('WAITING');refreshReady();showToast('ล้างข้อมูล Run แล้ว');
  }catch(e){showToast(e.message||'ล้าง Run ไม่สำเร็จ',5000);btn.disabled=false;}
}
function setStep(n){$$('.step').forEach((el,i)=>{el.classList.toggle('active',i+1===n);el.classList.toggle('done',i+1<n)});}
async function pollRun(id){
  clearInterval(state.polling);
  const tick=async()=>{
    try{
      const res=await fetch(`/api/status?id=${encodeURIComponent(id)}`); const run=await res.json(); state.run=run;
      setProgress(run.progress||0,run.message||'กำลังประมวลผล'); $('#logBox').textContent=(run.logs||[]).join('\n'); $('#logBox').scrollTop=$('#logBox').scrollHeight;
      if(run.status==='completed'){
        clearInterval(state.polling);$('#cancelRunBtn').disabled=true;$('#deleteRunBtn').disabled=false;setStatus('COMPLETED','ready');setStep(5);state.summary=run.summary;showToast('ประมวลผลสำเร็จ!');$('#runBtn').disabled=false;renderApproval();await loadDashboard();renderReport();
      }else if(run.status==='failed'){
        clearInterval(state.polling);$('#cancelRunBtn').disabled=true;$('#deleteRunBtn').disabled=false;setStatus('FAILED','failed');setStep(3);showToast(run.error||'ประมวลผลไม่สำเร็จ',7000);$('#runBtn').disabled=false;
      }else if(run.status==='cancelled'){
        clearInterval(state.polling);$('#cancelRunBtn').disabled=true;$('#deleteRunBtn').disabled=false;setStatus('CANCELLED','failed');setStep(3);showToast('หยุดการรันแล้ว',4500);$('#runBtn').disabled=false;
      }
    }catch(e){console.error(e)}
  };
  await tick(); state.polling=setInterval(tick,1200);
}

function downloadFile(key){
  if(!state.currentRunId){showToast('ยังไม่มีผลลัพธ์');return;}
  location.href=`/api/download?id=${encodeURIComponent(state.currentRunId)}&file=${encodeURIComponent(key)}`;
}
async function saveResultsToFolder(){
  if(!state.currentRunId){showToast('ยังไม่มีผลลัพธ์');return;}
  if(!$('#approvalCheck').checked){showToast('กรุณาติ๊กยืนยันว่าตรวจสอบ KPI แล้ว');return;}
  if(!window.showDirectoryPicker){showToast('เบราว์เซอร์นี้ยังไม่รองรับการบันทึกลงโฟลเดอร์ กรุณาใช้ปุ่มดาวน์โหลดไฟล์ด้านบน',5500);return;}
  try{
    const dir=await window.showDirectoryPicker({mode:'readwrite'});
    const files=[
      ['master','เช็คกรมธรรม์ต่างด้าวที่ยังไม่ออก V.2.5.3.xlsx'],
      ['issue','เช็คสถานะ ISSUE.xlsx'],
      ['csv','Pending_Detail.csv'],['audit','Audit_Report.txt'],['summary','summary.txt']
    ];
    for(const [key,name] of files){
      const res=await fetch(`/api/download?id=${encodeURIComponent(state.currentRunId)}&file=${encodeURIComponent(key)}`);
      if(!res.ok)throw new Error(`บันทึก ${name} ไม่สำเร็จ`);
      const handle=await dir.getFileHandle(name,{create:true});const writable=await handle.createWritable();await writable.write(await res.blob());await writable.close();
    }
    showToast('บันทึกผลลัพธ์ลงโฟลเดอร์สำเร็จ',5000);
  }catch(e){if(e?.name!=='AbortError')showToast(e.message||'บันทึกไฟล์ไม่สำเร็จ',5500);}
}
function bindDownloads(){
  document.addEventListener('click',e=>{const btn=e.target.closest('.download-btn');if(btn)downloadFile(btn.dataset.file)});
  $('#openOutputBtn').addEventListener('click',async()=>{if(!state.currentRunId)return;const r=await fetch(`/api/open-output?id=${encodeURIComponent(state.currentRunId)}`);const d=await r.json();if(d.path)showToast(`เปิดโฟลเดอร์: ${d.path}`)});
  $('#saveFolderBtn').addEventListener('click',saveResultsToFolder);
}
function renderApproval(){
  const ready=state.run?.status==='completed'||state.summary;
  $('#approvalEmpty').classList.toggle('hidden',!!ready); $('#approvalContent').classList.toggle('hidden',!ready);
  if(!ready)return;
  const s=state.summary||{};const metrics=[
    ['Daily Report',summaryNum(s,'ReportRowsAfterDateStatusFilter')],['M190 PropID',summaryNum(s,'M190PropIdRows')],
    ['ETL PropID',summaryNum(s,'EtlPropIdRows')],['ออกแล้ว ตัดออก',summaryNum(s,'IssuedRowsRemoved')],
    ['Pending เข้า Master',summaryNum(s,'PendingRowsWrittenToData')],['Data เข้า ISSUE',summaryNum(s,'IssueDataRowsWritten')],['Check เข้า ISSUE',summaryNum(s,'IssueCheckRowsWritten')]
  ];
  $('#approvalReconcile').innerHTML=metrics.map(([k,v])=>`<div><span>${esc(k)}</span><strong>${fmt(v)}</strong></div>`).join('');
}

async function loadCurrentRun(){
  if(!state.currentRunId)return;
  try{
    const r=await fetch(`/api/status?id=${encodeURIComponent(state.currentRunId)}`); if(!r.ok)return;
    const run=await r.json();state.run=run;state.summary=run.summary||null;$('#currentRunLabel').textContent=run.id;
    if(run.status==='running'||run.status==='queued'){setPage('prepare');$('#progressPanel').classList.remove('hidden');$('#deleteRunBtn').disabled=true;pollRun(run.id)}
    else if(run.status==='completed'){setStatus('COMPLETED','ready');$('#deleteRunBtn').disabled=false;renderApproval();loadDashboard();renderReport()}
    else if(run.status==='failed'){setStatus('FAILED','failed');$('#deleteRunBtn').disabled=false}
    else if(run.status==='cancelled'){setStatus('CANCELLED','failed');$('#deleteRunBtn').disabled=false}
  }catch{}
}

async function loadDashboard(){
  if(!state.currentRunId){showDashboardEmpty();return;}
  const q=new URLSearchParams({id:state.currentRunId,page:String(state.page),pageSize:String(state.pageSize),search:$('#searchInput')?.value||'',status:$('#statusFilter')?.value||'all'});
  try{
    const res=await fetch(`/api/result?${q}`); if(!res.ok){showDashboardEmpty();return;}
    const data=await res.json(); state.summary=data.summary||{}; state.total=data.total||0;
    $('#dashboardEmpty').classList.add('hidden');$('#dashboardContent').classList.remove('hidden');renderSummary(data.summary||{});renderRows(data.rows||[]);renderReport();
  }catch{showDashboardEmpty()}
}
function showDashboardEmpty(){$('#dashboardEmpty').classList.remove('hidden');$('#dashboardContent').classList.add('hidden')}
function summaryNum(s,k){return Number((s||{})[k]||0)}
function renderSummary(s){
  $('#kpiPending').textContent=fmt(summaryNum(s,'PendingPolicies'));$('#kpiIncomplete').textContent=fmt(summaryNum(s,'IncompletePolicies'));$('#kpiOverdue').textContent=fmt(summaryNum(s,'OverduePolicies'));$('#kpiBlacklist').textContent=fmt(summaryNum(s,'BlacklistPolicies'));$('#kpiMenuE').textContent=fmt(summaryNum(s,'MenuEPolicies'));
  $('#sumPremium').textContent=money(summaryNum(s,'TotalPremium'));$('#sumPolicies').textContent=fmt(summaryNum(s,'TotalPolicies'));$('#sumRows').textContent=fmt(summaryNum(s,'TotalRows'));$('#sumValidation').textContent=s.ValidationStatus||'-';
  $('#sumDateRange').textContent=(s.DateStart&&s.DateEnd)?`${s.DateStart} ถึง ${s.DateEnd}`:'-';
  $('#sumReportRows').textContent=fmt(summaryNum(s,'ReportRowsAfterDateStatusFilter'));$('#sumM190').textContent=fmt(summaryNum(s,'M190PropIdRows'));$('#sumETL').textContent=fmt(summaryNum(s,'EtlPropIdRows'));$('#sumIssuedRemoved').textContent=fmt(summaryNum(s,'IssuedRowsRemoved'));$('#sumPendingWritten').textContent=fmt(summaryNum(s,'PendingRowsWrittenToData'));
  const ages=[summaryNum(s,'Age_1_7'),summaryNum(s,'Age_8_15'),summaryNum(s,'Age_16_30'),summaryNum(s,'Age_Over_30')];const max=Math.max(1,...ages);
  ages.forEach((v,i)=>{$(`#age${i+1}`).textContent=fmt(v);$(`#age${i+1}Bar`).style.width=`${Math.round(v/max*100)}%`});
}
function statusClass(status){if(status==='Blacklist')return'black';if(status==='ข้อมูลไม่สมบูรณ์')return'incomplete';if(status.includes('เมนู E'))return'menu';return'pending'}
function renderRows(rows){
  $('#resultBody').innerHTML=rows.length?rows.map(r=>`<tr><td>${esc(r.proposalId)}</td><td>${esc(r.policy)}</td><td title="${esc(r.agencyName)}">${esc(r.agencyName)}</td><td>${esc(r.alienCode)}</td><td>${esc(r.alienName)}</td><td>${money(r.totalPremium)}</td><td>${esc((r.createDate||'').slice(0,10))}</td><td><span class="status-tag ${statusClass(r.pendingStatus)}">${esc(r.pendingStatus)}</span></td><td>${fmt(r.agingDays)} วัน</td></tr>`).join(''):'<tr><td colspan="9" style="text-align:center;color:#667085;padding:28px">ไม่พบข้อมูล</td></tr>';
  const pages=Math.max(1,Math.ceil(state.total/state.pageSize));$('#tableSummary').textContent=`พบ ${fmt(state.total)} แถว`;$('#pageInfo').textContent=`หน้า ${state.page} / ${pages}`;$('#prevPage').disabled=state.page<=1;$('#nextPage').disabled=state.page>=pages;
}
function bindDashboard(){
  let timer;$('#searchInput').addEventListener('input',()=>{clearTimeout(timer);state.page=1;timer=setTimeout(loadDashboard,280)});$('#statusFilter').addEventListener('change',()=>{state.page=1;loadDashboard()});
  $('#prevPage').addEventListener('click',()=>{if(state.page>1){state.page--;loadDashboard()}});$('#nextPage').addEventListener('click',()=>{if(state.page*state.pageSize<state.total){state.page++;loadDashboard()}});$('#refreshDashboard').addEventListener('click',loadDashboard);
}

function renderReport(){
  const s=state.summary; const ready=!!s;
  $('#reportEmpty').classList.toggle('hidden',ready);$('#reportSheet').classList.toggle('hidden',!ready);if(!ready)return;
  const total=summaryNum(s,'TotalPolicies');
  const pending=summaryNum(s,'PendingPolicies'), incomplete=summaryNum(s,'IncompletePolicies'), menuE=summaryNum(s,'MenuEPolicies'), blacklist=summaryNum(s,'BlacklistPolicies');
  const overdue=summaryNum(s,'OverduePolicies');
  const items=[['รอ Issue',pending,'ดำเนินการตามคิว'],['ข้อมูลไม่สมบูรณ์',incomplete,'ติดตามข้อมูลเพิ่ม'],['ติดปัญหาไม่เข้าในเมนู E',menuE,'เร่งตรวจสอบระบบ'],['Blacklist',blacklist,'ตรวจสอบเป็นกรณีพิเศษ']];
  const dateRange=(s.DateStart&&s.DateEnd)?`${s.DateStart} ถึง ${s.DateEnd}`:'-';
  $('#reportProcessed').textContent=s.ProcessedAt||'-';
  $('#reportRunId').textContent=state.currentRunId||'-';
  $('#reportDateRange').textContent=dateRange;
  $('#reportValidation').textContent=s.ValidationStatus||'-';
  $('#reportPolicies').textContent=fmt(total);$('#reportPremium').textContent=money(summaryNum(s,'TotalPremium'));$('#reportOverdue').textContent=fmt(overdue);$('#reportPending').textContent=fmt(pending);$('#reportPendingCard').textContent=fmt(pending);$('#reportIncomplete').textContent=fmt(incomplete);$('#reportMenuE').textContent=fmt(menuE);$('#reportBlacklist').textContent=fmt(blacklist);
  $('#reportDailyRows').textContent=fmt(summaryNum(s,'ReportRowsAfterDateStatusFilter'));$('#reportM190').textContent=fmt(summaryNum(s,'M190PropIdRows'));$('#reportETL').textContent=fmt(summaryNum(s,'EtlPropIdRows'));$('#reportIssuedRemoved').textContent=fmt(summaryNum(s,'IssuedRowsRemoved'));$('#reportPendingWritten').textContent=fmt(summaryNum(s,'PendingRowsWrittenToData'));$('#reportIssueDataRows').textContent=fmt(summaryNum(s,'IssueDataRowsWritten'));
  const urgent=overdue+incomplete+menuE+blacklist;
  $('#reportExecutiveNote').textContent=total===0?'ไม่พบกรมธรรม์คงเหลือในรอบข้อมูลนี้':`มีกรมธรรม์คงเหลือ ${fmt(total)} รายการ มูลค่า ${money(summaryNum(s,'TotalPremium'))} โดยมี ${fmt(urgent)} รายการที่ควรติดตามเป็นพิเศษ และ ${fmt(overdue)} รายการมีอายุงานเกิน 7 วัน`;
  $('#reportStatusBody').innerHTML=items.map(([name,count,action])=>`<tr><td>${esc(name)}</td><td>${fmt(count)}</td><td>${total?((count/total)*100).toFixed(2):'0.00'}%</td><td>${esc(action)}</td></tr>`).join('');
}
function bindReport(){
  $('#printReportBtn').addEventListener('click',()=>window.print());
  $('#refreshReportBtn').addEventListener('click',async()=>{await loadDashboard();renderReport();showToast('อัปเดตรายงานแล้ว');});
}

function historyDateTime(value){
  const d=new Date(value);
  if(Number.isNaN(d.getTime()))return '-';
  return d.toLocaleString(currentLang()==='en'?'en-GB':'th-TH',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
}
function retentionCountdownText(expiresAt){
  const end=new Date(expiresAt).getTime();
  if(!Number.isFinite(end))return '-';
  const remaining=Math.max(0,end-Date.now());
  if(remaining<=0)return currentLang()==='en'?'Deleting expired files':'ครบกำหนดลบไฟล์';
  const totalHours=Math.floor(remaining/3600000);
  const days=Math.floor(totalHours/24);
  const hours=totalHours%24;
  const minutes=Math.max(0,Math.floor((remaining%3600000)/60000));
  if(currentLang()==='en'){
    if(days>0)return `${days}d ${hours}h remaining`;
    if(hours>0)return `${hours}h ${minutes}m remaining`;
    return `${minutes}m remaining`;
  }
  if(days>0)return `เหลือ ${days} วัน ${hours} ชม.`;
  if(hours>0)return `เหลือ ${hours} ชม. ${minutes} นาที`;
  return `เหลือ ${minutes} นาที`;
}
function updateRetentionCountdowns(){
  $$('.history-retention-countdown[data-expires-at]').forEach(el=>{
    el.textContent=retentionCountdownText(el.dataset.expiresAt);
    const expired=new Date(el.dataset.expiresAt).getTime()<=Date.now();
    el.classList.toggle('expired',expired);
  });
}

function historyStatusLabel(status){
  return ({queued:'รอรัน',running:'กำลังรัน',completed:'เสร็จสมบูรณ์',failed:'ล้มเหลว',cancelled:'ยกเลิกแล้ว'})[status]||status||'-';
}
function resetDeletedCurrentRun(id){
  if(state.currentRunId!==id)return;
  clearInterval(state.polling);state.polling=null;state.currentRunId='';state.run=null;state.summary=null;
  localStorage.removeItem('blackwolf.currentRunId');$('#currentRunLabel').textContent='-';
  $('#progressPanel').classList.add('hidden');$('#logBox').textContent='';setProgress(0,'กำลังเตรียม...');
  $('#cancelRunBtn').disabled=true;$('#deleteRunBtn').disabled=true;setStatus('WAITING');refreshReady();
}
async function cancelDeleteHistoryRun(id,status,button,displayName=''){
  const active=status==='running'||status==='queued';
  const runName=displayName||id;
  const message=active
    ?`ต้องการหยุดและลบ ${runName} หรือไม่?\n\nระบบจะหยุดเฉพาะ Excel/PowerShell ของ Run นี้ และลบไฟล์ที่คัดลอกไว้ใน Run นี้เท่านั้น ไฟล์ต้นฉบับจะไม่ถูกลบ`
    :`ต้องการลบ ${runName} หรือไม่?\n\nระบบจะลบประวัติและไฟล์ภายในของ Run นี้เท่านั้น ไฟล์ต้นฉบับและไฟล์ที่ดาวน์โหลดออกไปแล้วจะไม่ถูกลบ`;
  if(!confirm(message))return;
  button.disabled=true;button.textContent=active?'กำลังหยุด...':'กำลังลบ...';
  try{
    const res=await fetch(`/api/cancel-delete-run?id=${encodeURIComponent(id)}`,{method:'POST'});const data=await res.json();
    if(!res.ok||!data.ok)throw new Error(data.error||'ลบ Run ไม่สำเร็จ');
    resetDeletedCurrentRun(id);
    showToast(data.cancelled?'หยุดและลบเฉพาะ Run นี้แล้ว':'ลบ Run นี้แล้ว',4500);
    await loadHistory();
  }catch(e){showToast(e.message||'ลบ Run ไม่สำเร็จ',5500);button.disabled=false;button.textContent=active?'หยุดและลบ':'ลบ';}
}
async function loadHistory(){
  try{
    const res=await fetch('/api/history');const data=await res.json();const list=data.runs||[];
    if((data.deletedExpiredRuns||0)>0)showToast(`ลบ Run ที่ครบ 14 วันแล้ว ${fmt(data.deletedExpiredRuns)} รายการ`,4500);
    $('#historyList').innerHTML=list.length?list.map(r=>{
      const active=r.status==='running'||r.status==='queued';
      const displayName=r.displayName||`เช็คกรมธรรม์ต่างด้าวที่ยังไม่ออก ${String(r.startedAt||'').slice(0,10)}`;
      const policyText=r.summary?.TotalPolicies?fmt(r.summary.TotalPolicies)+' กรมธรรม์':'-';
      return `<div class="history-item" data-id="${esc(r.id)}">
        <span class="history-created">${esc(historyDateTime(r.startedAt))}</span>
        <div class="history-run-main" title="Run ID: ${esc(r.id)}"><strong>${esc(displayName)}</strong><small>${esc(r.message||'')}</small></div>
        <b class="${esc(r.status)}">${esc(historyStatusLabel(r.status))}</b>
        <span>${policyText}</span>
        <span class="history-retention-countdown" data-expires-at="${esc(r.expiresAt||'')}">${esc(retentionCountdownText(r.expiresAt))}</span>
        <button type="button" class="history-delete-btn ${active?'active-run':''}" data-run-id="${esc(r.id)}" data-run-status="${esc(r.status)}" data-run-name="${esc(displayName)}">${active?'หยุดและลบ':'ลบ'}</button>
      </div>`;
    }).join(''):'<div class="empty-row">ยังไม่มีประวัติ</div>';
    $$('.history-item').forEach(el=>el.addEventListener('click',async e=>{if(e.target.closest('.history-delete-btn'))return;state.currentRunId=el.dataset.id;localStorage.setItem('blackwolf.currentRunId',state.currentRunId);await loadCurrentRun();setPage('dashboard')}));
    $$('.history-delete-btn').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation();cancelDeleteHistoryRun(btn.dataset.runId,btn.dataset.runStatus,btn,btn.dataset.runName)}));
    updateRetentionCountdowns();
  }catch{showToast('อ่านประวัติไม่สำเร็จ')}
}

async function saveSettings(){
  try{
    const res=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(state.settings)});
    const data=await res.json();
    if(!res.ok||!data.ok)throw new Error(data.error||'บันทึกการตั้งค่าไม่สำเร็จ');
    state.settings=data.settings||state.settings;
    return true;
  }catch(e){showToast(e.message||'บันทึกการตั้งค่าไม่สำเร็จ',5000);return false;}
}

async function loadSettings(){
  try{
    const res=await fetch('/api/settings');const data=await res.json();
    if(res.ok&&data.ok)state.settings={...state.settings,...data.settings};
  }catch{}
  applyLanguage(state.settings.language);
  applyTheme(state.settings.theme);
}

function statusText(ok,yesTh='พร้อมใช้งาน',noTh='ไม่พร้อมใช้งาน'){
  if(currentLang()==='en')return ok?'Ready':'Not ready';
  return ok?yesTh:noTh;
}

async function loadManualStatus(){
  try{
    const res=await fetch('/api/manual-status');const data=await res.json();
    const btn=$('#downloadManualBtn');
    if(data.available){
      btn.disabled=false;btn.innerHTML=currentLang()==='en'?'Download PDF Manual':'ดาวน์โหลดคู่มือ PDF';
      $('#manualStatusText').textContent=data.filename||'BLACKWOLF_User_Manual.pdf';
    }else{
      btn.disabled=true;btn.innerHTML=tr('manualButtonWaiting');
      $('#manualStatusText').textContent=tr('manualWaiting');
    }
  }catch{}
}

async function loadSystemStatus(){
  try{
    const res=await fetch('/api/system-status');const data=await res.json();
    if(!res.ok||!data.ok)throw new Error(data.error||'อ่านสถานะไม่สำเร็จ');
    const checks=data.checks||{};
    $('#settingsEngineStatus').textContent=statusText(!!data.engineReady);
    $('#settingsEngineStatus').className=data.engineReady?'status-ok':'status-bad';
    $('#settingsExcelStatus').textContent=statusText(!!checks.excel,'พร้อมใช้งาน','ไม่พบ Excel');
    $('#settingsExcelStatus').className=checks.excel?'status-ok':'status-bad';
    $('#settingsPowerShellStatus').textContent=statusText(!!checks.powershell,'พร้อมใช้งาน','ไม่พบ PowerShell');
    $('#settingsPowerShellStatus').className=checks.powershell?'status-ok':'status-bad';
    $('#settingsStorageStatus').textContent=statusText(!!data.storageWritable,'เขียนไฟล์ได้','เขียนไฟล์ไม่ได้');
    $('#settingsStorageStatus').className=data.storageWritable?'status-ok':'status-bad';
    $('#settingsManualStatus').textContent=data.manualAvailable?(currentLang()==='en'?'Available':'พร้อมดาวน์โหลด'):(currentLang()==='en'?'Waiting for file':'รอเพิ่มไฟล์');
    $('#settingsManualStatus').className=data.manualAvailable?'status-ok':'status-warn';
    $('#settingsActiveRuns').textContent=fmt(data.activeRuns||0);
    $('#settingsActiveRuns').className=(data.activeRuns||0)>0?'status-warn':'status-ok';
    $('#storagePathText').textContent=data.storagePath||'-';
    state.settings.storageDir=data.customStorage?(data.storagePath||''):'';
  }catch(e){showToast(e.message||'อ่านสถานะระบบไม่สำเร็จ',4500)}
  await loadManualStatus();
}

function bindSettings(){
  $$('[data-language]').forEach(btn=>btn.addEventListener('click',async()=>{
    applyLanguage(btn.dataset.language);await saveSettings();await loadSystemStatus();
  }));
  $$('[data-theme-value]').forEach(btn=>btn.addEventListener('click',async()=>{
    applyTheme(btn.dataset.themeValue);await saveSettings();
  }));
  $('#refreshSystemStatusBtn')?.addEventListener('click',loadSystemStatus);
  $('#chooseStorageBtn')?.addEventListener('click',async()=>{
    const btn=$('#chooseStorageBtn');btn.disabled=true;
    try{
      const res=await fetch('/api/select-storage',{method:'POST'});const data=await res.json();
      if(!res.ok||!data.ok)throw new Error(data.error||'เลือกโฟลเดอร์ไม่สำเร็จ');
      if(!data.cancelled){state.settings.storageDir=data.path||'';$('#storagePathText').textContent=data.path||'-';showToast('บันทึกโฟลเดอร์จัดเก็บแล้ว');}
      await loadSystemStatus();
    }catch(e){showToast(e.message||'เลือกโฟลเดอร์ไม่สำเร็จ',5000)}finally{btn.disabled=false;}
  });
  $('#openStorageBtn')?.addEventListener('click',async()=>{
    try{const res=await fetch('/api/open-storage');const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'เปิดโฟลเดอร์ไม่สำเร็จ');showToast(`เปิดโฟลเดอร์: ${data.path}`)}catch(e){showToast(e.message,5000)}
  });
  $('#useDefaultStorageBtn')?.addEventListener('click',async()=>{
    state.settings.storageDir='';if(await saveSettings()){showToast('กลับไปใช้พื้นที่จัดเก็บเริ่มต้นแล้ว');await loadSystemStatus();}
  });
  $('#downloadManualBtn')?.addEventListener('click',()=>{location.href='/api/manual'});
  $('#resetProgramBtn')?.addEventListener('click',async()=>{
    if(!confirm(currentLang()==='en'?'Reset BLACKWOLF settings, Run history, and temporary files? Original Excel files will not be deleted.':'ต้องการรีเซ็ตการตั้งค่า ประวัติ Run และไฟล์ชั่วคราวของ BLACKWOLF หรือไม่? ไฟล์ Excel ต้นฉบับจะไม่ถูกลบ'))return;
    if(!confirm(currentLang()==='en'?'Confirm reset. Active Runs will be stopped.':'ยืนยันอีกครั้ง: Run ที่กำลังทำงานจะถูกหยุดและลบเฉพาะข้อมูลภายใน BLACKWOLF'))return;
    const btn=$('#resetProgramBtn');btn.disabled=true;
    try{
      const res=await fetch('/api/reset',{method:'POST'});const data=await res.json();
      if(!res.ok||!data.ok)throw new Error(data.error||'รีเซ็ตไม่สำเร็จ');
      localStorage.removeItem('blackwolf.currentRunId');state.currentRunId='';state.run=null;state.summary=null;
      state.files={master:null,issue:null,daily:null,m190:null,sm:null,blacklist:null};
      state.settings={language:'th',theme:'light',storageDir:''};
      applyLanguage('th');applyTheme('light');showToast('รีเซ็ตโปรแกรมเรียบร้อยแล้ว',4000);
      setTimeout(()=>location.reload(),900);
    }catch(e){showToast(e.message||'รีเซ็ตโปรแกรมไม่สำเร็จ',5500);btn.disabled=false;}
  });
}

function bindMisc(){
  $('#runBtn').addEventListener('click',startRun);$('#refreshHistory').addEventListener('click',loadHistory);
}

async function init(){
  bindNavigation();bindFiles();bindEtl();bindDownloads();bindDashboard();bindReport();bindSettings();bindMisc();
  await loadSettings();validateEtl();await checkHealth();await loadCurrentRun();await loadSystemStatus();
  setInterval(updateRetentionCountdowns,60000);
}
init();
